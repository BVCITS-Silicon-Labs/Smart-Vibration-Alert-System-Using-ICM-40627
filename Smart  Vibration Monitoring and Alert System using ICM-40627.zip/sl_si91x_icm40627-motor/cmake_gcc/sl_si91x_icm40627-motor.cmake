####################################################################
# Automatically-generated file. Do not edit!                       #
####################################################################

set(SDK_PATH "C:/Users/digit/.silabs/slt/installs/conan/p/simpl965e19baece23/p")
set(COPIED_SDK_PATH "simplicity_sdk_2025.12.2")
set(PKG_PATH "C:/Users/digit/.silabs/slt/installs")

add_library(slc OBJECT
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/board/silabs/src/rsi_board.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/chip/src/iPMU_prog/iPMU_dotc/ipmu_apis.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/chip/src/iPMU_prog/iPMU_dotc/rsi_system_config_917.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/chip/src/rsi_deepsleep_soc.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/chip/src/rsi_ps_ram_func.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/chip/src/startup_si91x.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/chip/src/system_si91x.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/common/src/rsi_debug.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/common/src/sl_si91x_stack_object_declare.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/common/src/syscalls.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/config/src/rsi_nvic_priorities_config.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/cmsis_driver/SPI.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/cmsis_driver/UDMA.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/cmsis_driver/USART.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/hardware_drivers/icm40627/src/sl_si91x_icm40627.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/aux_reference_volt_config.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/clock_update.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/rsi_adc.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/rsi_crc.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/rsi_dac.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/rsi_egpio.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/rsi_opamp.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/rsi_spi.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/rsi_sysrtc.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/rsi_udma.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/rsi_udma_wrapper.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src/rsi_usart.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/service/clock_manager/src/sl_si91x_clock_manager.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/service/sleeptimer/src/sl_sleeptimer_hal_si91x_sysrtc.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/systemlevel/src/rsi_bod.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/systemlevel/src/rsi_ipmu.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/systemlevel/src/rsi_pll.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/systemlevel/src/rsi_rtc.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/systemlevel/src/rsi_temp_sensor.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/systemlevel/src/rsi_time_period.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/systemlevel/src/rsi_ulpss_clk.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/unified_api/src/sl_si91x_adc.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/unified_api/src/sl_si91x_bjt_temperature_sensor.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/unified_api/src/sl_si91x_dma.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/unified_api/src/sl_si91x_driver_gpio.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/unified_api/src/sl_si91x_ssi.c"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/unified_peripheral_drivers/src/sl_si91x_peripheral_gpio.c"
    "${SDK_PATH}/platform_common/platform/common/src/sl_assert.c"
    "${SDK_PATH}/platform_common/platform/common/src/sl_syscalls.c"
    "${SDK_PATH}/platform_core/platform/common/src/sl_core_cortexm.c"
    "${SDK_PATH}/platform_core/platform/service/sl_main/src/sl_main_init.c"
    "${SDK_PATH}/platform_core/platform/service/sl_main/src/sl_main_init_memory.c"
    "${SDK_PATH}/platform_core/platform/service/sl_main/src/sl_main_process_action.c"
    "${SDK_PATH}/platform_core/platform/service/sleeptimer/src/sl_sleeptimer.c"
    "../app.c"
    "../autogen/sl_event_handler.c"
    "../icm40627_example.c"
    "../main.c"
)

target_include_directories(slc PUBLIC
   "../config"
   "../autogen"
   "../."
    "${SDK_PATH}/platform_common/platform/common/inc"
    "${SDK_PATH}/cmsis/Core/Include"
    "${SDK_PATH}/platform_core/platform/common/inc"
    "${SDK_PATH}/platform_core/platform/service/sl_main/inc"
    "${SDK_PATH}/platform_core/platform/service/sl_main/src"
    "${SDK_PATH}/platform_core/platform/service/sleeptimer/inc"
    "${SDK_PATH}/platform_core/platform/service/sleeptimer/src"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/cmsis_driver/CMSIS/Driver/Include"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/cmsis_driver"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/common/inc"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/rom_driver/inc"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/chip/inc"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/inc"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/board/silabs/inc"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/core/config"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/service/sl_log/inc"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/unified_api/inc"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/service/clock_manager/inc"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/unified_peripheral_drivers/inc"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/hardware_drivers/icm40627/inc"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/service/sleeptimer/inc"
    "${SDK_PATH}/../../wisecd4a93bcc8f553/p/components/device/silabs/si91x/mcu/drivers/systemlevel/inc"
)

target_compile_definitions(slc PUBLIC
    "SL_COMPONENT_CATALOG_PRESENT=1"
    "SL_CODE_COMPONENT_CORE=core"
    "SL_CODE_COMPONENT_SLEEPTIMER=sleeptimer"
    "SIWG917M111MGTBA=1"
    "SLI_SI917=1"
    "SLI_SI917B0=1"
    "SLI_SI91X_MCU_ENABLE_FLASH_BASED_EXECUTION=1"
    "SLI_SI91X_MCU_EXTERNAL_LDO_FOR_PSRAM=1"
    "SI917_DEVKIT=1"
    "SLI_SI91X_MCU_COMMON_FLASH_MODE=1"
    "SLI_SI91X_MCU_CONFIG_RADIO_BOARD_BASE_VER=1"
    "SLI_SI91X_MCU_CONFIG_RADIO_BOARD_VER2=1"
    "SL_BOARD_NAME=\"BRD2605A\""
    "SL_BOARD_REV=\"A02\""
    "__FREERTOS_OS_WISECONNECT=1"
    "CLOCK_ROMDRIVER_PRESENT=1"
    "ULPSS_CLOCK_ROMDRIVER_PRESENT=1"
    "SL_SI91X_BOARD_INIT=1"
    "SRAM_BASE=0x0cUL"
    "SRAM_SIZE=0x2fc00UL"
    "SLI_CODE_CLASSIFICATION_DISABLE=1"
    "SLI_SI91X_MCU_ENABLE_IPMU_APIS=1"
    "SL_SI91X_SOC_MODE=1"
    "CRC_ROMDRIVER_PRESENT=1"
    "SPI_MULTI_SLAVE=1"
    "DEBUG_ENABLE=1"
    "DEBUG_UART=1"
    "ENABLE_DEBUG_MODULE=1"
    "SL_SI91X_SI917_RAM_MEM_CONFIG=1"
    "UDMA_ROMDRIVER_PRESENT=1"
    "__STATIC_INLINE=static inline"
    "SI917=1"
    "SLI_SI91X_MCU_INTERFACE=1"
    "TA_DEEP_SLEEP_COMMON_FLASH=1"
    "SL_SI91X_REQUIRES_INTF_PLL=1"
    "SL_SI91X_SSI_DMA=1"
    "SSI_CONFIG=1"
    "SSI_DUAL_QUAD_COMPONENT=1"
    "SSI_INSTANCE_CONFIG=1"
    "SI91X_PLATFORM=1"
    "SI91X_SYSRTC_PRESENT=1"
    "SL_SLEEP_TIMER=1"
    "__WEAK=__attribute__((weak))"
    "PLL_ROMDRIVER_PRESENT=1"
)

target_link_libraries(slc PUBLIC
    "-Wl,--start-group"
    "gcc"
    "c"
    "m"
    "nosys"
    "-Wl,--end-group"
)
target_compile_options(slc PUBLIC
    $<$<COMPILE_LANGUAGE:C>:-mcpu=cortex-m4>
    $<$<COMPILE_LANGUAGE:C>:-mthumb>
    $<$<COMPILE_LANGUAGE:C>:-mfpu=fpv4-sp-d16>
    $<$<COMPILE_LANGUAGE:C>:-mfloat-abi=softfp>
    $<$<COMPILE_LANGUAGE:C>:-Wall>
    $<$<COMPILE_LANGUAGE:C>:-Wextra>
    $<$<COMPILE_LANGUAGE:C>:-Os>
    $<$<COMPILE_LANGUAGE:C>:-fdata-sections>
    $<$<COMPILE_LANGUAGE:C>:-ffunction-sections>
    $<$<COMPILE_LANGUAGE:C>:-fomit-frame-pointer>
    $<$<COMPILE_LANGUAGE:C>:-g>
    $<$<COMPILE_LANGUAGE:C>:--specs=nano.specs>
    "$<$<COMPILE_LANGUAGE:C>:SHELL:-Wall -Werror>"
    $<$<COMPILE_LANGUAGE:C>:-Wno-error=deprecated-declarations>
    $<$<COMPILE_LANGUAGE:C>:-mcpu=cortex-m4>
    $<$<COMPILE_LANGUAGE:C>:-fno-lto>
    $<$<COMPILE_LANGUAGE:CXX>:-mcpu=cortex-m4>
    $<$<COMPILE_LANGUAGE:CXX>:-mthumb>
    $<$<COMPILE_LANGUAGE:CXX>:-mfpu=fpv4-sp-d16>
    $<$<COMPILE_LANGUAGE:CXX>:-mfloat-abi=softfp>
    $<$<COMPILE_LANGUAGE:CXX>:-fno-rtti>
    $<$<COMPILE_LANGUAGE:CXX>:-fno-exceptions>
    $<$<COMPILE_LANGUAGE:CXX>:-Wall>
    $<$<COMPILE_LANGUAGE:CXX>:-Wextra>
    $<$<COMPILE_LANGUAGE:CXX>:-Os>
    $<$<COMPILE_LANGUAGE:CXX>:-fdata-sections>
    $<$<COMPILE_LANGUAGE:CXX>:-ffunction-sections>
    $<$<COMPILE_LANGUAGE:CXX>:-fomit-frame-pointer>
    $<$<COMPILE_LANGUAGE:CXX>:-g>
    $<$<COMPILE_LANGUAGE:CXX>:--specs=nano.specs>
    "$<$<COMPILE_LANGUAGE:CXX>:SHELL:-Wall -Werror>"
    $<$<COMPILE_LANGUAGE:CXX>:-Wno-error=deprecated-declarations>
    $<$<COMPILE_LANGUAGE:CXX>:-mcpu=cortex-m4>
    $<$<COMPILE_LANGUAGE:CXX>:-fno-lto>
    $<$<COMPILE_LANGUAGE:ASM>:-mcpu=cortex-m4>
    $<$<COMPILE_LANGUAGE:ASM>:-mthumb>
    $<$<COMPILE_LANGUAGE:ASM>:-mfpu=fpv4-sp-d16>
    $<$<COMPILE_LANGUAGE:ASM>:-mfloat-abi=softfp>
    "$<$<COMPILE_LANGUAGE:ASM>:SHELL:-x assembler-with-cpp>"
)

set(post_build_command ${POST_BUILD_EXE} postbuild "./sl_si91x_icm40627-motor.slpb" --parameter build_dir:"$<TARGET_FILE_DIR:sl_si91x_icm40627-motor>")
set_property(TARGET slc PROPERTY C_STANDARD 17)
set_property(TARGET slc PROPERTY CXX_STANDARD 17)
set_property(TARGET slc PROPERTY CXX_EXTENSIONS OFF)

target_link_options(slc INTERFACE
    -mcpu=cortex-m4
    -mthumb
    -mfpu=fpv4-sp-d16
    -mfloat-abi=softfp
    -T${CMAKE_CURRENT_LIST_DIR}/../autogen/linkerfile_SoC.ld
    --specs=nano.specs
    "SHELL:-Xlinker -Map=$<TARGET_FILE_DIR:sl_si91x_icm40627-motor>/sl_si91x_icm40627-motor.map"
    -fno-lto
    -Wl,--gc-sections
    "SHELL:-u _printf_float"
)

# BEGIN_SIMPLICITY_STUDIO_METADATA=eJztfQlz5DaS7l9xKBwv7Letoqp0lKTt9oRcUvfWG6mlVUn2zNveYEAkqkSLV/OQ1Hb4vy/AqwiSIAmSIKBZew6reGR+mUgkEkAy8cfOanl1c7lcLO/+qa7u7s+X1+rN+dVq53Tn/d9eLfPLl++eoecbjv3hy850svdlB12Btubohr1Bl+7vPu4ef9n5209fvnzx0P/s967n/Aa1AD1mAwuiR0JtYjl6aMKJD4PQnYTawrHXxmbim6pvnExfVUOzDvaOZvNdywkcb7LRtIgNouRCL/i20tC/EaGU8k7GDD2E/vt+7Zg69LYctYh+6bn0acOE22dLINT47cljhGEDbeiBAOro0cALYXTRNOyn6MoamD66pLRlZELoBoYFPZ5MIml831BD01Vdz7CA900AP8tybO5sdQtw5KE5HuRF/qMH4e3d9WrBh/zt3YV6Dp8NDaon0zkP5Tw4wNMT7YSIKnIRXNkEnmMOzsA1eNroxjWcWACOHS8A2hP6+/chLPW9ErvS4mXD1sxQhzcgeEQ/Q8/ACIJQN5xTJfHKSup0tzTfp/eyK9/xG1PuoOWaSF5+owoIAwdptd2wgvvfwrFcx4Z24Cdt8hAaZmDY+RYpN1N755RQVzUQANPZ8GACnzGDR2DrJvT4M9CGZ4AHJsNGvcTWIJd2wAyqRrvhmES91sPX1JWzmJh6d/p9Onhm/0J6ePLAFQyAjuxdkm6OHpwknAzo/29sl8wNraKf3JrFg74TehpWMqVhSi8A3YKUp6s7M5ZAN8DGA9bEtTeVQ2bWDPjdU2Vxqtz7SKWKbmyMQJn4hgkefMU3AyXyOqbp45ER2IqrvBg+1PQDcLL/oGnH68PDfXQRvgI0cEH0SjycO5qCFGS4j8hiTKWkTiXTgxILqJRRVzuVSpGdMHDDYPp2pCUAU7wnpS9RLhftxjcQQkMzgm+qrz+ps73Z4WQ6m8za2h2OQtaOZyWDQoMBUl6ufYvybgt+te8jX9P6ZdpgCALHMrRkBCTdFVKmUtBN9ltJfiMICkGlzpTb4EGeDcXFJkCD9NrQ8pOUzuAoJHsiNThApdLsq1VED/nw3q2cUenfyphu/4ZNqQyAxzW2AXMfRBmdvpiQdw5Cvy+iLZW2eChut7VX8r0BvFJsaVpH2REEhaDSuy2++RoeK/siytMZvD1aPFj7SP3N0uBl+QYttKO8snC8+vCO8t4yjqkZBkqi/SKkzV08ekzBGJWEoVJ+s3WjVUFIInl2BLkXOwIIfo9W5OArfRCo4E6+1Ut2NJ1glzt5qSvjaDHYOmDim3unI1vLDVXgWc9zFr7ES82Mx+3qOefW0IGlCo+HGIiSDQUP9QGrjfNHTUpx/UVKYw3HQ0wSMPY2gUiF9FlgFFMQMejRzAN6eLelh32ZqgWM9gY6mJnSmgmjUQ3baBU45dsqUYWS0EhNlqDHFkI1QlQtaDnet6GR5sgOAtgok2bsB9WIq+kOqGPXczTo+yrQojnkgGouU2aMrtkcGqXXsLu15l7Ts2UTV0fQ49RrBkY6igkOiLlMmasJ9p4RZ1kk8owVW0zdfUNKIZvdEjQH8r+5FJxHYHa3ogLYKsJv24/ltN9fSenqEUFz8BYdDGiRqBzugNMsre2+SLSf49g21IL9aGfkYLI3mbbdFcm2CRkXeXTYMqqu2MfBe1M94nG8E9XXw1pa2LE/lvTXarGrPb1Hw+1Bj6azjgNKC9LGzdU9HqlpaZ1DstGdYCg5SGaE8/J8A6/gBtBKEkeiTD1t+E3Xbd9T4u6kpCSwiSvIRqOFKgXbRDSeZbpWMnUoVLRd3DiTngzXClXgGr60uiEQDqmPTkHBOMQKA3FsGZHSpGimIqBhWqUodQC8IHRlEruIiIvc2Be4vuoBS12HtiaF5BWYuMmuo+AwihBxAos00pdQ9ZV/IIcx2CSlVdtAz3PImYCINsHzCAINF1t8AD5Ug28u9KUQmITDRWKc+imRxCQcbv5G09yqHBeRhk1CGmWUkUX0AiZushPRtjTSl1BxkR9xiCFJITeBhpe8EnVwAg0veSuSCAXK2zUZkc2XSdaXCUR8Zkj5aZgMYhcB8ZE6/jZVHgdWBMRRauvZlUjkBI3wmVB/Aj3TmVrT5TY5yz7ucMTG7mQ+cw4Rx+WCh1Cs09/KTODh5fLjpGQ5BM7DEe4GKH1uyG0TivWJXKTaJi4SePhYH/ldvPOAvy5EPDUTeFASLTRi5NsvJVFCh28XuPVLHsNzTQmaHnS5ugobNR2u4OJ4Bv6cOZ0cCDUYjCDzHXSAwk2IqlS8Uhb6xZI/IrVJQdVbha0NSg4V0MF110QPM+rzailrxjPwRz6DJoxEn9DEhId3a4ur1XLFK3XkfBjQtTxYPypjYUV0q1gYXFtG3GphYl5K3iaUqAmVGF72IVIJLfdskYTjRxP4j29FPRnYsbSznC3eim4SqGNpZnW2fCuaSaCOppmbt6OZm1E1c786u717K7rJwP6r56nxieilHX4HH2kLgn+SrP9/GqiTF8SUbGQcaPQrCCnZIDfQQFYUUi575WOu9+dXZzJJmeIZWkzZRtjBRtEKoxWz3EY12iEW1yqMViIpUzxcjFYmOVNAQta3Uh0VyzQ6FrdVJa6Jxhi4Zj6J2udMW3irv2x/N4+M26Z2xMQTlZXZJL3HNzUT84C4urec4mfQ+OWyAe3JsEWt5NeInwPG1/RFZS42WT7fHMbIutahLyqtrcnwU2hcFbA2LDnFT4BxFX7j6haQU/wMGlcFuM4L9FQfPEvaB0h8fFXxImlHSIBxFf6r7xpySp8i4yq+J+PonwPGVfgAPJhQvV1NX9E/cqqhBHEEhYhM82+lDr5p/xmvUjEaedTQp/hOawWE0oYI4RgRAmaivnjAdWU1gyJCvuowXd/HCxKS6iIPT3ga4fALbNvzNdT+aWEUHlyzUoEuqsZCajllFWYZqQk4Lh0IhK+qB9fQg7YG1WfHDMRm5DaooxYuFwVppqM9qaGr43PfpNRJESG/EgGexJ0kAcfvAysgsfAJOG7Cx4u90oqfweOmAMcFliuvAjJ4/ApFoOm+tOIn4HhWyfACibv/Fh83FUSTGmkVkKLjKn42mZFaDXmU/NThg8JZR3LpIYUnfKqVanDMpAE8XRA7C65omnQ2nIAbeS4jpTpq4fKfy0ipkyJCrnMZKTWQA8d1LiOt8Ak4znMZacXnn1eDcQIPBMJKWLbpAQRGfqoQnWFTpwK+WTYyZNjUdQPuWTYyJJnUKIB/oslGfHJBnfy8EwyMmcSDYAKOo/Cic4prheebVhyvlkkrfgaPX2at8JyqGvF551V9hRJ7vQQcP+Gl9vnck8owA3ywRiDxBIDEyC9rQnhuXY0OuOfXyR37edxjP1/mKbDPeQIstQ/k7QJ9uaXnLn68VSavAjJ8nFWgPkKgI86yqyKPk5tKopRViVWxxcd3g1daBXDPqZUon7ZBDaPk1MY7qPLqIYXHt76vdaC6knqFMkbhe93DpxUnh+dyyCU2VXOwUz457u7TzBOBR+Oi6eKP8CT4HiZ38LmJD62M7bMK5ED9VbLqXcUyptEmtgVssBmsJCjHdHiakcX+hRBGcMpPamcEJrLceQmuVBZHaUv+DqNKOXL4DLItiaGtBFeqtuR2UEN2LPwbdh2ZDOojyE4ikCGLdjtUpQgz/1GPWSrbozQsdz9iFLQkiQ/JNWbsQKpwStWAEgbboW2sDajjM8bf0Md72WAh/gu+nALJmITn93sZk4ffAjWAFoq2QRB6UPWh7TuiAzaqSuho+WpJ/FcMVJXw/IRhyyRCoUrwORddDyREzic4+aI/a6LqIYEmfFknVeDoZ/iJ/44h3zbEzITnVwxNPlJSldDR8vfokqqE555FpbuUVQ8kRF76kFoTI+lgO3RIpwECmvBRjd/86U3XQsnaKSeFRMEi5ZvPOtTCLY3ShPzjp6Iy5PAITfuZFaj5Oss3pJvxFKJqMhw+w6KXHGLhXX74weURePoLQGE1tyHF0KyDvaPZ/A1vOkS2kMoheMQqNpiS4iIHrDxaqRaoaVYy0k5lphexDojeioT/yaOVqhUl9GT+Nz+AlgmfofmG4mKcdPbg6KI3L7e6y2qdJKj4fSnoWqGEYqew+H0jZ5oSip2g4vdhjPgN+gqpeRe3wuuWcmyYVUlfQMc1CT4KtaX0cwV0/DKfs1K98umAwCZ8lpOqcMzaVni0E5xzkmuXNB09QcWvXo8vRb33KtHz0PjGIPLJnsLiGoPIJ3aCip/UUjY297aW5cifSuHHOe/H9RwN+ijOkWOvu1ITFRD5ReNwI8HHylVqyCHjKH2A8BnCV6Gr5c9h4zobk1B2zt8n5+c78klfQDfKbExCLZDoRpiNyaeDQQ91oWrg5UUX/SFulfApLOGz0B4EOr3K+FLrx1s82OaR4mz8wQGe3mI+Xl5Kj6yh9Ux+gKX4yuk+Qs95ISbikRl/tqqeMG5r36xm0X/VhKouvs6CUNd2ASRhzOYOaCIkdbBDD4wQ/tEFKsPoJZ5v4rKOYhqpyLuvIO6LJUwQgndfQXzDESYIwbu3IHG1HGGyFNj3FecrFOTOirz7CuL5B8eHwkQpcO8rTFSaVJgwBe6DD819QzDKTdplUrvATc+XMg37CepYq8D04fBahq9IjSZMIn3Vd7RckZlyUouSICuqu4A/fVxNyEsqTBXMBsmw/I9SCpMgY20ZOYWpgtkgmQeBbsGJpUspUA5dgxwWMOykv2ygjb+giuQIvBBWSlYiB181M9ShfgOCx5886DuhpyGgMQLFh0Ho6gbYeMCauPbmvUI8z0TLCQM3DKbNZJDPxvfwrawh/CDUDedUcT3nN6gFSoUkda/5+pPimiBYO56VpPtmv5XkdzSPYqaqWb7hKwvHg8oyfrQfNERnGGAUmrmCS9h2+BKPZvLDE8+XbOBKvz3+8ZfWIsNLT4xeXK2WK+U8/sFmh2KRSwcysgnmjje+EsnjwqWDGavx0XClRFdfIVEY3OLMRTq9JZ0DL21Jh41eUVBaqIVPXaXFSS24Ji3i+s+/pIVd+9GItKh7BWbC9yQrcFpA85xzuDZsAy/fb2dbq0t1cX11c/354vOduji7O7u8/qTe3F6s0G9mOucXeWLXtxfRhO0ZmGFUCRS52n4kV5cXFzd3y6uLW4JwvkggA/nlr59OpvOr6XR69enu5zM2aEt1tURvEzimnUj8vNefyD/Uq8W9evH57OfLC/Xj5dnqP9Sfz1YX5+rFPy4W93fL68+D8fjH3cXt57NL9fL8Wv14faverG7PrnpQxypQzy9++fuS0d7yqJCJXF1/TiS/QkYzlLiL688fl5/U27Pz5bX68/XZ7XmkWPWXggkOywJRn/Uhn5D5fHZFKuL/fA2d4N9/vj2fHe0dnsW/OlG+vfilgvDZ3oydpqp+vL24uL27Xqnov78uVxdIIZ8vFnfdFbC4vF78Xb29vjq/XSJVdnFn95c3q5U6ACGksripY8UtPzOaOepckcUR2th73dPuL5nprJb/v0hnttb29hhJIeuN/TLqbavlxyUaNZCDUc+XK+x+eruv5c3VvXp2s1x1UvPqepE4AAZ7uV30bOSbpXp1f3mHpLk8+4WJ9/nFz/efEtG7W3xM5f7stkevSdQfk0IqvO8DaNsekX/H1nd1cZX4uu5k78+vzvo1laqu7pC9LlBPvFx+JiVEUVlgaOiCYZuGzRarxMFAV9Nffkaj6sezBZPp3J2hxrq4iaMiYgjs1FK3F/95v0QKxWA+qjeXjE4hbe/VUkWNxPTuapkZBttb5/coEPnP+7PzbYzISmL5GdnD58VFb9OMxb+5PLtDUVHPgAip8Z+r27vF1sD79MPIPJKomaWj/Hpx9neCs6qCIPCMhzCAqvrDDy8QPP34IwtNZFSteq9pPHjA+/aR2BfaaFUTm8pHWz9otX3QdtAcq+LhwHHMazeREv9YRntV2dVJqE3wRA4R8yJdOtHlmqcm69DW8EUVzQnxv32iDeJtsDFw6CAAojGg6bGjaipqksEQAN+H1kMjhOwxHhiiLcwGAPEzPLgztoFjGYG69gDOcXcMO0heFGAMjgpfNegKNUhH9YLAGIo7/qU9AsOuZ589NtHcsLimEsDXXetgLADrAoC1+3yw67ujsTcdEKjggWwB31kH664YGDpj/K+V5hluQAD4Pt3EB2HgbKCtxE/ilUB15SwmZlXaw8Dg0mSJK+BGY5eYDqKpKIq29SjPPm+n0+OR+L++UhD8279VRugcMLwAzzbsjT8BpimoGTII8DXwgGgQLtSBjadWhOegpO9wbRAPqtDzHM8XBQU/YRm/R0n0pA8zfh8hnODBnjWuhA/hRk1qXuUQ6HANQjNoDcICTxA7WNSo1gRNDiYB8DYwKKKgPFYaSXctdOUD+3jaE0bwGFoPBSDJtXEAFAf0XQtd+ZAM67v69Gg0IJVDO4KDr++i6x8Yh/kSo+0g0Yhp+yhtRNv1A/0Dy7BWw8N1GQDhBGTaIBeDYhrpBoZVFSDvrm1nN74qDBRl5hBBy98b17bSgUktRgq7v0ZXxlcXf0Sd9FMOY3Z/Ta4J1BFXVCx6og7ru9eD2DSrhnjjYdENfR1rd43v7W7vja+oUcGxaK1+FXJ3nd4Xqj0hIJn6Zf3a2e4aP7AbPbCbPSCgu4qBydSLKbOG3aq0Tf7dlisaFr3Q1od3UfQONf8Dvj+J/hShpzHQVc9+KY/Rl/D6r9z1RBbpSiJNpeuJavxbtYBLIvtHQu/Ld7tXwP3w/Q/X93c393fq+fL2R+X7H25ur//fxeIOJyH9OIle7mt/JeSGT6sTEZG+NPwgI0/GsQjzr9FCUBlVMwE8ZcDvftCh60ENf6C2q0PNBHFthIoWaqTZtPjQSADPY8zAqVCystUyo/4fHT/4qwG6qhEpLUn6nRg6RH/uz2Jl6sEkTjjXH0LD1KPdjcnGDic55/kAko82c9rOESw8HT80wc0xcYJH6JlIxv8lDdO9ZzS+Sa14U8fNgr6P2nbXhPYmePywJ8iU8MoHizHln//LnP61zaltYNDJu3fXz6/mu93djVYzWWskEaIfquuhGcpajdaNxfW+JIpq2ffw02m/W5tgQ6s1xkXxLbTWrvEQArw2tuu9vKJW3Fj44xVRQymD/gntm/pf+q91GKb5bA3qMXLziPruP4Cno2Z/dYP+in5kJHdfjOBxN5oj81D5m4EeFyaIemqSFlNEHH/PpjpucQ/6ZXMynVvT6dTaBA8dVtGzGcuQ9inLoNLSpbGS0wxPC1FIhWIsaOvQ1r51TxeRRyobWYJeWk1hS/ToM/APIMo2iGBsovdpTZnsynfv//Zq4WAcfy6KIKGXppP4u0NEzdENe4Mu3d993D3+svO3LaG0/27P9dUmlqOHqKtFdXQmi6isxE382A3S+c+REKX6P7uWEzjeJMrhRtQQXRd6wbeVhv6NyGZ+otgwFSUKK8j6phvnUGAVBoad6eRLVQ2hUuu7CHek/FUA3Z++/wHXygBIz96PGGp6E/0df932/Q8JXLzKlfz5GQH8McKRfAGHBzMX4BXzIBraIhKqbninKZHoCrrwY3wBNRoBQ0BjJhk4KxgEUbZU51ZU+GMdzuRGAOuisQN3a5kxhlqi0gE7b6Gsb7LEThuBi48jIFHuTQBriwEXfMRE87SkVi3+s7tbSEf2dmUMy910591OsgSu3l5f3+2c7vzxZef24vLsbvnLhZq/9WXnFOGefNn5E72zWl7dXC4Xy7t/qqu7e/xNcPwt3goR+K8/cJk3y3mGOnonGszefdlJpLuI64+hAe/0v/57e3kVlyzDV/EohPWifPQgxF/cLmI1PX7ZeZfdu727UM/j+AzFYuQ9ZMepaonryGIoNYKrnwk8xyzdxeUBaNSjM42zWpfErdhUdQvQ3iVtuf4pP65kj6M9C3jfkrpqrO/UPRwA7UnFyZbU57JiBrkncHvGvTWylbQ3n15dRRe/Qy7B9k+Tqx+Q9e08BoF7qigvLy9p2IFkUXxfSXs5jMoxoCe3veNL0hXwRUOPfpe9RGIzdU4Cv+/qFkHwp6hX2N8lJTOw6/K/c0GARseY8+T/4v9Xkuey7pSK+FOkpgQqUgKm++e7vv0h3fTDRr/I6m0kbVKzI5i7G1lu8qaqgQCYzqZAAD0Cn/HtRxRVJDu8dbdLb2MTqzLFwiNRXREbCSeZydxBC5ekg/9iRoP+N0nGQgPfk0bjCYsrGACcQ/TG1I4fo9fZjEg3FvWMG6Oy8eL6ve+ySrbvqqv1Vl2On07rk74jSq5WoeoA+x1eBUHMDM0Ivqm+/qTO9maHk+lsMquoy5nUHcw2bh47EsAT0a7vJnFol/ejAd866PCq5YYq8KzneYd3g9+jEAS+Bk0vtyivil0vXkXzBiMWOJbR2BotiaH5ANKwiQAaa0PLB2X9KeNfwxFrZb8tyeEpQ+gPQ8zgoUN8rsrWbrRBiPnffA3XFGMgV12XNw3FGYSsIJSgSmJ6vNtqdURWUd03/VvFBQY64mwiq1porPK+caCeHJqoAo3RlhrKEpNaGUbZRbKpVoanXtDKkAyM4Vs1XxWQnLQNTdrgQjt1GlvSfRVeIJ2HjeY16Ww/KnTo2DYKFvcjDgeTvcm0/YlKPUlUrk90IFg8QKgzlcIhHp3pEKcAdaZCHPXSmUrhlJXOdPzCkk9HKoWjeNgJlU5Ba0WiVRVpBW96qcE3F/qtsbUjHH1XwoMwtMh4d0C6REw5IN34wYHpYovQNJcPaEw8SnzjQNf1yTWkgWmjmayKP7vhQD2ucssHfbKKzMNSYtLWszs03Vgd0e0BSWN3Z+ASjCgi28R/6U6ArrlWiMt6+wO6QBqvUmtHWxHD8sU8dBSiRHEKPr+GA/18fxiWOprjekHoJq0/MO28YQ1Deju7jNX+EA7VgcmZf9TVnKHGvBztdHY9JOGtFWJ1DKnoNLzPbTk5D3iFVo2zp+Hw3Mjlh96Eo92wdIwNfWIzbFD6NnoMb905noFX8XmwSduZwqqvxlqfnpP8VBfDhCzMfD+awH8cn+1ythif6epsKYDpjQCm96uz2zs+bEew10/cdMbN7LiZFlYFF2fETce4HDQfyBFlPpij/sIH9KBdsfbklnJizQh8ibAm4zuUKqsP1lFA+Kp6cA09aGtQfXbMYKgYoYFxfDRR6Oo4c4IzLxyeAL3/pL0FG0wFf783wOJGG27eOEL1Xw5rwUUHowgD1yjgHoURTusbg9HG1S0wCiPfNcbgY8xGsQRj1n/G24JNtAsyBiP3xRqDzVc4ihF8HcnYMB+8QheM0lc9m/vIGrEZyyX447i4kWzBH4tPtG03Hif1EQIdXR6DY7QpPgqncCQbx3zUFw+4Lhwlqgt9MMAGZAOjbKZhHagu1+bC8xr6NIPj/AYzJqYZnHml04wR2ODAfwQ2OCQfgU0cKY/AKA7FRmCEx5Ex2MTjyAicIl87Ep/M147BL/K1QzEiz3iPg3KgPRkDBn0VLPAlzXwazonTeAy42kBjMdy4R+Ew7PSfxmTQqT+FydoYbrpHYTHsygKFieu8QE/1wTP3ZhlygkxhMeislcJjyDkkhUUAHkyo3q6mr+ifcZgNk+nTxCqXaMyNyaDzkhoeg89JaLxM1/fxCDMYozSxOo7O4wIhHjktIW5xZkzsvJCMh4oMcrn7Jk4Gi0VFf6Kpueli/zeo+bdKuGfKXO/AsZSGjxmmaTvDRq5xUldUsTqXE98+JboLfd0f2J1UMcF5iVwZuOaANlBFnzf+4aOHSjbxBzwOYgVtf8DdvSpmHtwMuuJZzSNA77J8J9KJy4CrnFX00QV3jBbBHV3F00jOPoXDUFvB5eVFH26elWew/Zik/6ckdfQjr8iTAfaKPOnzGvtS+vl+wZVPrl/w5LPtF0NxCW1jbUAd5/yn0Vh8Sx107l7BJg6AhsxHoTJ5+C2ITAHXggo9OLSnpPIdcgJEZzJmc/n+cMNxngkx9Rhy84DKhGIT3PkOuYBMZ5KzCe7MsE0MzaRpt46LtbdhOtSngKy8c/fHkp1o5CJ/TaJKSJm4q+jn2yqERCthVF8FVRrdL9hLw76VNpBGxywVW/9SLqNy/zJdrkXqWtTEfStK3dYE3NasVUqFaKVRfbtSv6Mp/7933u1ojotijY+GCf2kzm1WoDd57F1WaPgGBI+RBrVWNV4dz9gYNjCz16KrOI7B5d53TqfvIkp4sQ/92p1Oj/YPDo+mJ7PIKthgVNVuZYZwsLc/RRBmBx0ApGE3vSItG5aT+cHewXw+nQ6HpVzGlLWFDvYPD05m85O9rqBK1YJZERzOkJFMZwdH7AjKZY4Zmc+Pp/P9GbJQRt6VRZ9ZBZ/P905OkH2yCl5ZVZqV+fHB/vRwejDt0O708k+s2p8dIAjzg+MeGHLlrxm5z/YO50gBh/N9Rvalyt2MjA8PjvdP9md7rHyranezNvtsf350PN8/mXf2QZSi26xATg4OkTM8Pm49MrSJCjq0xdF0b292OD9hhVFZ5ZqN+Rzp4GR6dMDMu6ZMNmsPnM4P94+O9w87QKiqs83GfjY/2D86QkFGb+5d2n66hxoA/XfaOjaoKxHOzv7wCPn/45NOzU8rYs7Y/MgPIXdwcNzaAdeXcWfVP/JGJwhC6yGIViy8S9BxsDefTY+Pym2fTliKzNsVnGbDsY+dD+qD5ZGgNYpiXWzGNkCNcLg/P5mXLYCGYFv0mzH6RY19eLxfbmwaI0olcdaW3p/vHx5O50dlJ1MnYcdg+vhojkKa/fa8KHXRGVtxHwfQ8/lh2ZXQ7ShfbZ111JjP0OB90p5brsw7q2TzAzRKHB+19hH1C7odosSD+eH8+GT/OJpalw+Uubm9vrm4vVtGZ8r8QeUfcfoDz+dx8pC+Chzt6RfgGTgZ1ceXT/H/4QfwPzsu8IJr105/nqZ/lE71S66/S/+I5/4r/enSietrV5CoLkub3v8z/j+slPN4RfTtYf8zd17Q6vr+dhG1TnTaU/Gsp+qTnrztKU91RzR50fJNfHpRemZSPB5nd7+Lz1SinrqWG7+/Cz0Dn6uHHj9VFqfKvY/3h3RkroGyyiRfRSdCKo8Q4ApkAYxqPJfXbWKzU4rhewVbhY60agmGM8oqljUIG9ZoxlApnTs77kJEJwZ+AUSTFOQC0BiQSY50fIXlIb7QCswoqMoLRxxRlZlRUJVXlDiiKjOjtyBlqYlvS1KYtkCZLkaNhC9lR0FGrlNxxEQyouuJXL3iqySSV6MnrlrVGsX7VjFO0W4PRqwKNHInQGayEQ+QZz4mzxQ0UFpC4yF0m6W7XAuRUle4KnLdjSfiMre60aZiSY4nOBpPOsTSkh1neCV+baFxNsQqfjUuorjWxxlaiV89tFGixqa1RwrEinVCnugq2FGAFZcQeaIq8mrn3rOVPrqDjxdx6M69vELJQ8wWC6MKDSGxejkKOIIjddCpbxrqMgS1pQoHjxWarPJR4pmKVYYSnYqnDFsrPVJ2Ittj8upaYJImt5qBEnkn0/RxOANsxVUijZwcHcLpyQOAGpzto4vMp/QpjVApB8gJwU3B0igE9Rg8EVJQwTS3xfboGjFmk7FvYzZpNrkgS0nZt4Kand8oCmwGoBnu9nxIIWC37ItQS7OISgfpe60cZHa45LhCls62bNEeubMjhIDNA2jVJhUXyzPA8pSQHA1x5e66QRUfWls/oCaV+CtG1JyCy0cED6vjVqcSl7RaRpjscYwIMMexFh95YDB3cCS7FppLTm8eSWsJt3pcuZOd+cPKMatFRRwazR0WwU0Z3H0QB3KOFZu3G3qKh/5y8+ntzx3uNtK2m4qkhyWPKWYW98Ssuw5a5QaOa9Q02kF8vm6lcloYTFmHxLnFoyiyzQHK5dClBnnuaGQpBMjhaSFH9RnJAgWpBtS6RcrHSQtvlDKkitC42i+19Ex1/UpUaxoVx7V36leyCDCANcogShlSa2tsOU3NsmKGGybI88pH1mH94emtfGy5spxYGaoQ8XdK5IH2ojSQrsYQYBhbUTz+Ipp+nbjDxKR+16G6CgV9z2FbnqJuShNXrqif0MSabwxk8f5Ls3+ytJBi2QX0pRUb2pOPhkt5srVzrHw4O0255pXql/DBy7UvFXoC9Yzmzh0iMhb9AJzsP2ja8frwMJpZNxcs6XGedFV/p8hLnH8toYwEvjq5qO68/QOERyycFi1YNUU4dE2QUhTP0xYtRhFPSzkqTh0XLEkFIgZZSie0SyBNCRNNnoaO1DJ8omgGep7TLwDpr5HsIL8US8uWfQA+VINvbnNq0ggCkGBaSqCDAEgjAQmGoXfhw9UH2GcezpBIQB19nhyiFBAxyEJEKpJIU8LUUh70TsxEAjkILO3xS9NBCCzt8Q+Q8zIY/roEmLq+LVVfIPC0jS/zYal4MYpw2koRf8okS4cuwmGSwnp2pREhwdIpjqy/2WqXl/I0Q0CapbI6IuMhMs0qh4dpwvEQinQ0WxkINO3dTJzJJIMAeTDDTJGalsIq21LcpHGbkkCgaduW5PdWzgP+ghtR0UzgQSmkakTIarVSCFWTDNjKatkccuHD+yHN30YC40+kHc/AH3HkzpMVpeT4O8KkP9DhdXYWFdPb0G9dCYC75BRMVHFbNqgMYtGhVUtX05R1twr7QHE58pZbLlH2YvxK2w63uFotV+03X87riVe8QcvgrTGEmIm6EDcrTavA5zWqRKpSYnBZDmQJK8N+S/LuRxP4j29DzAwqu5TL2eJtyJgAZZdwdbZ8GxImQDtIePNWJLzpKOH96uz27m3ImEHluRPKEo9I6rZbe2hCmE9S2fqnBoMmoEvlaRu8KQFcKgfa4CRJ4DLZCoup3J9fncmDPEXTDrpcnrrRG5cMRsQklWowdVPSksFIgzxFw2Aw8mBP4TDPHktTrO2R3RzWvdMDwDXzScyaa8PB5CkuhgXw6DVPzC56kzQe61Y6fgump6LJJk4GjGUvFGhPhi1mzadGnBwsVlMTszPdZGmse9RRe65DX8y2aJOhpcAYBVobloziJLAYhdm4yZmrsomTAWMUiDzXXTapSHSsor1IaXgJLEZhviYH1csmTYqLURxPvtEnB4tRmADXA1dvV9NX9I+MYpUAdhJQXNpRK/FY05Cyt3t/g8VLrLrvyWoECiUdosJuIxR+TX3xgOvK2UxFfKzima7v4ymWlLLlwXHPYyifEc0ppyE5AF6YtimHYeegtTQiEL6qHlxDD9oaVJ8dMxCZn9EgXi3YlgJrpqM9qaGrg0BM9lKDjEV8LJ9ReNIaZQKNJQESSCtMAo1BGJieSC+jOBk4BoEcF1iurAJl4Fg+dkGTEEnFSaCxfbnjBdJ2ny06BpGi0E9SgVJsjOJkIZ/EYuUxsojng55FP3nKlYIT8r0sDs9ExukViknj9QRa78hRQvFqwXaJHCWUsYiPMXKUUKIcNMbIUVJhEmjMkaOk4nTZOcScgQcCQUUD2lgcgZBFNLF7iHUise4jit9DrDO7DvuI4rfdagTqsvW2Eb2dUycP+5aOMZPWaSfQmIQRm4VTKwxrIk48m5ZUnAwcS+6K4F3dGnHYd3a/Qmm9QAKNRRiJfVqHbWr8Ci6PFkgbwJEIWfadBO++18jUYQde5tjA6xAb+PJOGXzmCYPEPoHdJfgyS9NBnHgpV1aBMnTMIqmPEOiIltyi5VEyiBilhUgr2hYd6/aApAJ1yFqRJmOlQayOWSvxCryscqXgWOujWAeqK2WvKiPknojjUw5woT1uqmZtrWimPZdyAyHiyFeaLk4FFp6DmDsOwcSlk+MWqoJYY4E9vwgmS1JEGwcWsMGmtmwEU8oUrZcQzIRuEabtQCAiCwqVwHZukd4mXAVIBismtUe4mxLYkey59sgP2jusxkwcWJHWnxKfd9HmnJBKxMIse9DjSDior3zABf2Ikrb2OtQwG9rG2oA6rrfPIdE168iis11zYpL+mS3XNXvt4bdADaCFxloQhB5UfWj7jtjBiCoiHSur1KIzqKgisqVPbV+L6KrCUyvpcpEAmest+mJTEqlyJcBGT58iur3IUSKvGSLiYcugaurjUopIx9rFH0kpItt6TWV3l1MuEmB7+SSWrLNMW1cmmUQEMO4LNSmAUb6cyqTLcZNm+KZkDNdhFjcCFsHIYMNNq48VmFm765uRtY+AIk/66CJni9NABnNXj8DTXwAKOxidlKFZB3tHsznv1c2Uj1CPVlSSkqIiHVoeq+h1zQyLSKOn642w+TxW8UtA8REqJnyGJqdvnR8cXeyS5lbC7BueBBNLTqZrhdKJkYJiyV40TenESDCxpFyJXiavkIL9o0Q8D5Zh8bBKmgI2xvSQaOCXsN8XsLHkHGSFKGSTiUAm5JtE7E2F7rrktJKmYSSYWL778iWoxFMlSh4Y64glmywpKMYRSzYxEkwsUkjYGB3aQo5ifZXCdK3U53qOBn00zsmwbl4pWQVAllgJboQnQVeJlcPFJE2AOBqC1zeq5ckhY4xlpZOFOe85Hy/KJk0BW8dYVjqpSGydYlnZZGpV7q1CopcXXWxCcJUwKaihVzWptyg3Ki9XXKy6RM4LHhzg6YWZQXFxKNJQafbQagmpYmKB+HGdcEUcsmbNVocStsWWoym4zeyJIhxPoyWE206MErZls6yGmFQ6CT3AfdilAy6DaIDvm/jDaxFKLnJuBuq+WIKAEpybgfqGIwgowbkF0Pj7JkFYC8yb4X6FQtxBkXMzUM8/OD4UBLXAuxls9HG/ILAF3q0GkjZDcuFC8WdeA8BtrLC4MizXNDQj+LYKQt1wlEcI8MnHAdSwmy3vWe1aTuB4SkJaqWKbPqrCV6QCs7FIalcMVXwqAWGwDc3fRw+PbfXACUMVn0pAHgS6BSeWzgdHjnwlewsYNi9bSGlXMqa8NPFN94EPnHqOGUgipEnRnsM1CM0AAUPuBJrElcidLHB5qcB4MEyEC8fknj472jsEp3sT/J+zvRl60gVeUHwQTVcmwLMmL2sLubuXzcl0bk2nU2sTPAD0SuA4pvaIFFl8D3m6xD1OfH+y9hDOF8d7mriegw9Kn+AzlCe2c4feX+D3YyCIoq8/1dHSnyY+PnAdXUB/n872ZoeT6Wwym6jTo+nJbDY9Pjk4PNo/OZ4fzvdyAfV7+BqdkanfgODxJw/6Tuhp0E8MUPFhELq6ATYI6MS1N+8V4vmWVJwwcMNgWkdAh77mGS5uvJ/eK/lfqW8mGji6+l5JtBb92vnzfwCJm7p1=END_SIMPLICITY_STUDIO_METADATA